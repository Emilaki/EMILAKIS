# EA EarnHub pilot

## Local preview
Install Python 3.10+ and dependencies, then run:

\`pip install -r requirements.txt\`
\`python app.py\`

Open http://127.0.0.1:8000.

Without a funded reserve, signup bonuses and tasks stay paused. Configure an admin key with \`EA_ADMIN_TOKEN\` before attempting to fund the reserve.

## Public preview deployment
This repo includes a Render Blueprint (\`render.yaml\`) that can create a Python web service and PostgreSQL database. Connect the project repository to Render and create the Blueprint. It will provide an \`onrender.com\` URL. You may later attach a domain you own. Render's free Postgres tier is for previews only and expires after 30 days; do not keep real account or balance records there. Upgrade to a paid persistent database before any real beta.

After deploy:
- Set a private, unique \`EA_ADMIN_TOKEN\` in the Render service environment and keep it secret.
- Use HTTPS (Render terminates HTTPS; \`EA_HTTPS=1\` marks session cookies secure).
- Seed the reward pool only with sponsor funds already received.
- The starter deployment uses a free service and database for a no-money preview; it is not a production account/payment service.

## Pilot functions
- Registration and login with PBKDF2 password hashing and server-side session records.
- PostgreSQL in hosted environments; SQLite for local preview.
- Fixed reward claims wait for operator review and funded reserve.
- Referral credit only follows an approved first activity, if funds remain.
- Withdrawal requests: minimum KSh 50, maximum KSh 500 per rolling 24 hours.
- Operator can review claims, queue and reconcile withdrawal requests.
- No pay-to-unlock tasks, deposits, chance-based cash rewards, or live M-Pesa connection.

## Not ready for real users or money
This remains a starter pilot and needs a security review before public account registration. It does not yet have email verification, production rate limiting, automated M-Pesa payments, a complete support/appeals flow, or finalized legal/privacy documents. The task descriptions are placeholders, not proof of task completion. The operator must verify work before approving claims.

For M-Pesa, Safaricom Daraja has sandbox and production onboarding. Production needs the relevant product enabled for the business and live business account details. Do not place API secrets in the frontend, repository, or chat. Confirm the correct disbursement product and onboarding steps directly in Daraja.

Check applicable data protection registration and privacy requirements with the ODPC before collecting member data publicly.
